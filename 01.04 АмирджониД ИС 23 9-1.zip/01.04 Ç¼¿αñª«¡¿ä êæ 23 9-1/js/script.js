let game = {
    points: 0,
    clickPower: 1,
    autoIncome: 0,
    totalClicks: 0,
    level: 1
};

function save() {
    localStorage.setItem('clicker', JSON.stringify(game));
}

function load() {
    let data = localStorage.getItem('clicker');
    if (data) {
        let saved = JSON.parse(data);
        game.points = saved.points;
        game.clickPower = saved.clickPower;
        game.autoIncome = saved.autoIncome;
        game.totalClicks = saved.totalClicks;
        game.level = saved.level;
    }
}

function updateUI() {
    document.getElementById('points').innerText = Math.floor(game.points);
    document.getElementById('clickPower').innerText = game.clickPower;
    document.getElementById('autoIncome').innerText = game.autoIncome;
    document.getElementById('totalClicks').innerText = game.totalClicks;
    document.getElementById('level').innerText = game.level;
    
    document.getElementById('x2Cost').innerText = 10 + (Math.floor(game.clickPower / 10) * 5);
    document.getElementById('x5Cost').innerText = 50 + (Math.floor(game.clickPower / 5) * 8);
    document.getElementById('autoCost').innerText = 30 + (game.autoIncome * 10);
}

function updateLevel() {
    let newLevel = Math.floor(game.points / 100) + 1;
    if (newLevel > game.level) {
        game.level = newLevel;
    }
}

function clickHandler() {
    game.points += game.clickPower;
    game.totalClicks++;
    updateLevel();
    save();
    updateUI();
}

function buyX2() {
    let cost = 10 + (Math.floor(game.clickPower / 10) * 5);
    if (game.points >= cost) {
        game.points -= cost;
        game.clickPower += 2;
        updateLevel();
        save();
        updateUI();
    }
}

function buyX5() {
    let cost = 50 + (Math.floor(game.clickPower / 5) * 8);
    if (game.points >= cost) {
        game.points -= cost;
        game.clickPower += 5;
        updateLevel();
        save();
        updateUI();
    }
}

function buyAuto() {
    let cost = 30 + (game.autoIncome * 10);
    if (game.points >= cost) {
        game.points -= cost;
        game.autoIncome++;
        updateLevel();
        save();
        updateUI();
    }
}

load();
updateUI();

document.getElementById('clickBtn').onclick = clickHandler;
document.getElementById('upgradeX2').onclick = buyX2;
document.getElementById('upgradeX5').onclick = buyX5;
document.getElementById('upgradeAuto').onclick = buyAuto;

setInterval(() => {
    if (game.autoIncome > 0) {
        game.points += game.autoIncome;
        updateLevel();
        save();
        updateUI();
    }
}, 1000);