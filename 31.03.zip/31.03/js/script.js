
let schedule = JSON.parse(localStorage.getItem('schedule')) || [];
let editId = null;
function save() {
    localStorage.setItem('schedule', JSON.stringify(schedule));
}
function render() {
    let searchText = document.getElementById('search').value.toLowerCase();
    let dayFilter = document.getElementById('dayFilter').value;

    let filtered = schedule.filter(item => {
        let matchSearch = item.subject.toLowerCase().includes(searchText) || item.teacher.toLowerCase().includes(searchText);
        let matchDay = dayFilter === '' || item.day === dayFilter;
        return matchSearch && matchDay;
    });
    let grouped = {};
    filtered.forEach(item => {
        if (!grouped[item.day]) grouped[item.day] = [];
        grouped[item.day].push(item);
    });
    let container = document.getElementById('scheduleList');
    container.innerHTML = '';
    for (let day in grouped) {
        grouped[day].sort((a, b) => a.time.localeCompare(b.time));
        let dayDiv = document.createElement('div');
        dayDiv.className = 'day-group';
        dayDiv.innerHTML = `<h3>${day}</h3>`;
        grouped[day].forEach(item => {
            let itemDiv = document.createElement('div');
            itemDiv.className = 'schedule-item';
            if (editId === item.id) itemDiv.classList.add('editing');
            itemDiv.innerHTML = `
                <div><strong>${item.subject}</strong> - ${item.teacher} (${item.time})</div>
                <div>
                    <button onclick="editItem(${item.id})">Редактировать</button>
                    <button onclick="deleteItem(${item.id})">Удалить</button>
                </div>
            `;
            dayDiv.appendChild(itemDiv);
        });
        container.appendChild(dayDiv);
    }
    let stats = {};
    schedule.forEach(item => {
        stats[item.day] = (stats[item.day] || 0) + 1;
    });
    let maxDay = '';
    let maxCount = 0;
    for (let day in stats) {
        if (stats[day] > maxCount) {
            maxCount = stats[day];
            maxDay = day;
        }
    }
    let statsHtml = `<strong>Статистика:</strong> `;
    for (let day in stats) {
        statsHtml += `${day}: ${stats[day]} `;
    }
    statsHtml += `
<strong>Самый загруженный день:</strong> ${maxDay || 'нет'} (${maxCount} занятий)`;
    document.getElementById('stats').innerHTML = statsHtml;
}
function addItem() {
    let subject = document.getElementById('subject').value;
    let teacher = document.getElementById('teacher').value;
    let day = document.getElementById('day').value;
    let time = document.getElementById('time').value;

    if (!subject || !teacher || !time) return;

    if (editId !== null) {
        let index = schedule.findIndex(item => item.id === editId);
        schedule[index] = { id: editId, subject, teacher, day, time };
        editId = null;
        document.getElementById('addBtn').textContent = 'Добавить';
    } else {
        let newItem = {
            id: Date.now(),
            subject,
            teacher,
            day,
            time
        };
        schedule.push(newItem);
    }

    save();
    render();
    document.getElementById('subject').value = '';
    document.getElementById('teacher').value = '';
    document.getElementById('time').value = '';
}
function deleteItem(id) {
    schedule = schedule.filter(item => item.id !== id);
    if (editId === id) {
        editId = null;
        document.getElementById('addBtn').textContent = 'Добавить';
        document.getElementById('subject').value = '';
        document.getElementById('teacher').value = '';
        document.getElementById('time').value = '';
    }
    save();
    render();
}
function editItem(id) {
    let item = schedule.find(item => item.id === id);
    document.getElementById('subject').value = item.subject;
    document.getElementById('teacher').value = item.teacher;
    document.getElementById('day').value = item.day;
    document.getElementById('time').value = item.time;
    editId= id;
    document.getElementById('addBtn').textContent = 'Сохранить';
    render();
}
document.getElementById('addBtn').addEventListener('click', addItem);
document.getElementById('search').addEventListener('input', render);
document.getElementById('dayFilter').addEventListener('change', render);
render();