from django.shortcuts import render
from django.http import HttpResponse, HttpRequest
from .models import *

# Create your views here.

def json_view(request: HttpRequest) -> HttpResponse:
#     return HttpResponse("""
# {
#     "status": "ok",
#     "data" {
#         "value1": 123,
#         "value2": 6.5
#     }
# }
# """, content_type='application/json')
    items = Item.objects.all()
    return render(request,
                  'template.json',
                  {'items': items},
                  content_type='application/json')

