from django.db import models

# Create your models here.

class Item(models.Model):
    sku = models.IntegerField(verbose_name='Артикул')
    name = models.CharField(verbose_name='Наименование', max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        verbose_name = 'Товар',
        verbose_name_plural = 'Товары'

    def __str__(self):
        return self.name