from django.urls import path, include
from django.contrib.auth import views as auth_views
from views import *



urlpatterns = [
    # path('', views.profile, name='profile'),
    # path('home/', views.home, name='home'),
    # path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    # path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    # path('register/', views.register, name='register'),
    path('', MainPageView.as_view)
]

