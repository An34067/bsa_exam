# from django.shortcuts import render, redirect
# from django.contrib.auth.decorators import login_required
# from django.contrib.auth import login
# from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render
from django.views.generic import View, TemplateView, ListView, DetailView
from .models import *


# class MainPageView(View):
#     def get(self):
#         pass

#     def post(self):
#         pass

# class MainPageView(TemplateView):
#     template_name = 'index.html'
#     def get_queryset(self):
#         return self.model.objects.filter(color='black')
        


# class MainPageView(ListView):
#     # model = Item,
#     template_name = 'index.html'

# def main_page_view(request):
#     data = Item.objects.all()
#     return render(request, 'index.html', {'object_list': data})


# class MainPageView(DetailView):
#     # model = Item,
#     template_name = 'index.html'


class MainPageView(ListView):
    model = Book,
    template_name = 'index.html'

    def main_page_view(request):
        data = Book.objects.all()
        return render(request, 'index.html', {'object_list': data})
    

class MainPageView(DetailView):
    model = Book,
    template_name = 'index.html'




















# def home(request):
#     return render(request, 'home.html')

# def profile(request):
#     return render(request, 'profile.html')

# def register(request):
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             user = form.save()
#             login(request, user)  
#             return redirect('home')
#     else:
#         form = UserCreationForm()
#     return render(request, 'register.html', {'form': form})

# @login_required
# def protected_view(request):
#     return render(request, 'login.html')