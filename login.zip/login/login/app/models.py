from django.db import models

# Create your models here.

class Book(models.Model):
    title = models.CharField(max_length=30)
    author = models.CharField(max_length=30)

    class Meta:
        verbose_name = 'книга'
        verbose_name_plular = 'книги'
        ordering = ['author', 'title'] 

    def __str__(self):
        return f"{self.title} - {self.author}"