from django.urls import path
from .views import *

urlpatterns = [
    path('item/new/', ItemCreateView.as_view(), name='item-new'),
    path('item/<int:pk>/', ItemUpdateView.as_view(), name='itemupdate'),
]