from django.shortcuts import render
from django.views.generic import View, FormView, CreateView, UpdateView
from django.urls import reverse, reverse_lazy

from .models import Item

# Create your views here.

class ItemCreateView(CreateView):
    model = Item
    template_name = 'item_create.html'
    success_url = reverse_lazy('item-new')
    fields = ['item', 'price', 'manufacturer']

class ItemUpdateView(UpdateView):
    model = Item
    template_name = 'item_update.html'
    success_url = reverse_lazy('item-update')
    fields = ['item', 'price', 'manufacturer']

