from django.db import models

# Create your models here.

class Manufacturer(models.Model):
    name = models.CharField()
    country = models.CharField()

    class Meta:
        ordering = ['name']
        verbose_name = 'Производитель'
        verbose_name_plural = 'Производители'

    def __str__(self):
        return self.name

class Item(models.Model):
    item = models.CharField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    manufacturer = models.ForeignKey(Manufacturer, on_delete=models.CASCADE, related_name='manufacturers')
    class Meta:
        ordering = ['item']
        verbose_name = 'Товар'
        verbose_name_plural = 'Товары'

    def __str__(self):
        return self.item
    
