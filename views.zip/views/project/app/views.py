from django.shortcuts import render
from django.views.generic import ListView, DetailView

from app.models import *

# Create your views here.

class BookListView(ListView):
    model = Book
    template_name = 'book_list.html'
    context_object_name = 'books'

class AuthorView(ListView):
    model = Book
    template_name = 'author.html'
    context_object_name = 'books'

    def get_queryset(self):
        return Book.objects.filter(author_id=self.kwargs['author_id'])
    