from django.urls import path

from app.views import *

urlpatterns = [
    path('books/', BookListView.as_view(), name='book_list'),
    path('author/<int:author_id>/', AuthorView.as_view(), name='author_books')
]
