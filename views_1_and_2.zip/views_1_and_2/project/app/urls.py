from django.urls import path
from .views import *

urlpatterns = [
    path('', calculator, name='calculator'),
    path('books/', BookListView.as_view(), name='index'),
    path('author/<int:pk>/', AuthorBooksView.as_view(), name='author'),
]