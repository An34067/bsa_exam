#from django.shortcuts import render
#from django.views.generic import ListView, DetailView
#
#from app.models import *
#
## Create your views here.
#
#class BookListView(ListView):
#    model = Book
#    template_name = 'book_list.html'
#    context_object_name = 'books'
#
#class AuthorView(ListView):
#    model = Book
#    template_name = 'author.html'
#    context_object_name = 'books'
#
#    def get_queryset(self):
#        return Book.objects.filter(author_id=self.kwargs['author_id'])


from django.views.generic import ListView
from .models import Author, Book

class BookListView(ListView):
    model = Book
    template_name = 'index.html'
    context_object_name = 'books'

class AuthorBooksView(ListView):
    model = Book
    template_name = 'author.html'
    context_object_name = 'books'

    def get_queryset(self):
        return Book.objects.filter(author_id=self.kwargs['pk'])

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['author'] = Author.objects.get(pk=self.kwargs['pk'])
        return context
    
from django.shortcuts import render

def calculator(request):
    result = None

    if request.method == 'POST':
        num1 = float(request.POST.get('num1', 0))
        num2 = float(request.POST.get('num2', 0))
        op = request.POST.get('op')

        if op == '+':
            result = num1 + num2
        elif op == '-':
            result = num1 - num2
        elif op == '*':
            result = num1 * num2
        elif op == '/':
            result = num1 / num2 if num2 != 0 else 'Деление на ноль невозможно'

    return render(request, 'calc.html', {'result': result})