#from django.shortcuts import render
#from django.views.generic import ListView, DetailView
#
#from app.models import *
#
## Create your views here.
#
#class BookListView(ListView):
#    model = Book
#    template_name = 'book_list.html'
#    context_object_name = 'books'
#
#class AuthorView(ListView):
#    model = Book
#    template_name = 'author.html'
#    context_object_name = 'books'
#
#    def get_queryset(self):
#        return Book.objects.filter(author_id=self.kwargs['author_id'])







# views.py
from django.shortcuts import render


class View:
    @classmethod
    def as_view(cls):
        def view(request, *args, **kwargs):
            self = cls()
            self.kwargs = kwargs
            return self.get(request, *args, **kwargs)
        return view


class ListView(View):
    model = None
    template_name = None
    context_object_name = 'object_list'

    def get_queryset(self):
        return self.model.objects.all()

    def get(self, request, *args, **kwargs):
        objects = self.get_queryset()
        context = {self.context_object_name: objects}
        return render(request, self.template_name, context)


# ===== ИСПОЛЬЗОВАНИЕ =====

from .models import Author, Book


class BookListView(ListView):
    model = Book
    template_name = 'book_list.html'
    context_object_name = 'books'


class AuthorView(ListView):
    model = Book
    template_name = 'author.html'
    context_object_name = 'books'

    def get_queryset(self):
        return Book.objects.filter(author_id=self.kwargs['author_id'])    